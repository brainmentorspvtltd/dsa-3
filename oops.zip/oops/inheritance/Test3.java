package oops.inheritance;

class Organisms{
    int mass;
    String color;

    void eat(){
            System.out.println("only water");
    }
}
class Human extends Organisms{
    int brain;

    // void eat2(){
    //     System.out.println("veg fish milk water");
    // }
    void eat(){
        System.out.println("veg fish milk water");
    }


}
class Dog extends Organisms{
    void eat(){
        System.out.println("dog food");
    }
}
class Plant extends Organisms{
     void eat(){
         System.out.println("sunlight and co2");
     }
}

public class Test3 {
    public static void main(String[] args) {
        // Plant p=new Plant();
        // p.eat();
        // Human h=new Human();
        // h.eat();
        // h.eat2();

        //parent classes can hold the references of child classes
        //at runtime => jvm decides which method to call
        Organisms o=new Organisms();
        Human h=new Human();
        Dog d=new Dog();
        Plant p=new Plant();

//parent =>different child class => references
//runtime polymor, overriding
        o=h;
        o.eat();
        o=d;
        o.eat();
        o=p;
        o.eat();


    }
}
