package oops.inheritance;

import java.util.Scanner;
import java.lang.Math;
import java.math.BigDecimal;
import java.math.BigInteger;

//function overloading
//when there =>when different function are having same name but different signature
//that when you create an object =>parent constructor is ca;lled and child 
//generic 
//Vintage=>base structure=>4 wheels=>4 gates, seats, streeing wheel , engines

//they used the properties of the vintage cars=>with some modification
//basic struct=> inherit
//if we construct these cars from stratch=>time taking , research from start=>new modification will take time 
//java language=>backward compati
//users base=>old model 


//special
//Sedan 
//Suv
//Sports


class VintageCar{
    private boolean wood;
    public int speed;
    int fuelCapacity;
    int carNumber;
    String color;
    int height;

    VintageCar(){
        System.out.println("iam a vintage car constructor");
    }
    VintageCar(int speed, int fuelCapacity, int carNumber, String color,int height){
        this.speed=speed;
        this.fuelCapacity=fuelCapacity;
        this.carNumber=carNumber;
        this.color=color;
        this.height=height;
        System.out.println("Vintage para");
    }
}

class Sedan extends VintageCar{
    boolean dashboard;
    boolean autoGears;
    Sedan(){
        System.out.println("iam a sedan class constructor");
    }
    Sedan(boolean dashboard, boolean autoGears,int speed, int fuelCapacity, int carNumber, String color,int height){
        super(speed, fuelCapacity, carNumber, color,height);
        this.dashboard=dashboard;
        this.autoGears=autoGears;
        System.out.println("Sedan para");
    }
}

//multiple inheritance =>cpp possible =>java not possible
//class Suv extends Sedan , vintageCar

class Suv extends Sedan {
    boolean seatsExtra;
    Suv(){
        System.out.println("Suv");
    }
    Suv(boolean seatExtra){
        this.seatsExtra=seatExtra;
    }
    Suv(boolean seatExtra,boolean dashboard, boolean autoGears,int speed, int fuelCapacity, int carNumber, String color,int height){
        super(dashboard, autoGears,speed, fuelCapacity, carNumber, color,height);
        // this.speed=speed;
        // this.fuelCapacity=fuelCapacity;
        // this.carNumber=carNumber;
        // this.color=color;
        // this.height=height;

        // this.dashboard=dashboard;
        // this.autoGears=autoGears;

        this.seatsExtra=seatExtra;
        System.out.println("Suv para");
    }

    //functiom overloading 

    void printInfo(int choice){
        if(choice==1){
            if(this.seatsExtra==true){
                System.out.println("this car has 6 seats");
            }
            else{
                System.out.println("only 4 seats");
            }
        }
    }

    boolean printinfo(char choice){
        if(choice =='a'){
            if(this.dashboard==true){
                System.out.println("yes with dashboard");
                return this.dashboard;
                        }

        }
return this.dashboard;
    }
    void printInfo(){
        System.out.println("extra seats"+this.seatsExtra);
        System.out.println("Dashboard "+this.dashboard);
        System.out.println("Auto gears "+this.autoGears);
        System.out.println("color "+this.color);
    }

}
public class Test {
    public static void main(String[] args) {
        // Sedan s=new Sedan();
        // System.out.println(s.speed+" "+s.dashboard);
        Suv s=new Suv(true,true,true,12,13,14,"red",45);
        System.out.println("=======================");
        s.printInfo();
        System.out.println("=======================");
        s.printInfo(1);
        System.out.println("=======================");
        s.printInfo('a');
        System.out.println("=======================");
    }
}
