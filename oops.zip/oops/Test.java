package oops;
//properties =>private =>data hiding
//Encapsulation=>Data members and member function=>at one place=> binded together


//noun =>classes name=>object
//paybill
//verbs=>functionality=>function()
class Human{
    //private =>properties
    private int height;
    private int weight;
    private String hairColor;
    private String name;
    private String phone;

//constructors
//=>one time call
//just after the object is initialized with the default state=>primitve =>def values  and ref =null
// they dont have a return type
//once we have defined a constructros the constructor is lost
//if you default constructor now you have define it again

//overloaded function =>functions with same name but different signatures

//function signature

//1:void read(int a,int b){}
//2:int read(in firatNumber ,int secondNumber){}
//3:void read(int first , int second, int third){}
//4:void read(int first ,float second){}
//5:void read(float first , int second ){}
//1-3   2-3
//1-2 duplicate functions 
//read(12,13);
//read(12,13,14);
//sigantures=> read(int ,int ), read(int , int ), read(int, int ,int);
//if we are overloading a function => have distinct signatures
//name of function is same =>different parameter count, have different  types of argumnets
//order of arguments =>differ
Human(){
   // this();
this(45);
//this()=>constructor calling on the basis of signature
}
Human(int  height){
this.height=height;
}
Human(int height, int weight, String hairColor,String name , String phone )
{
    this.height=height;
    this.weight=weight;
    this.phone=phone;
    this.hairColor=hairColor;
    this.name=name;
}

//setters

    void setHeight(int height){
        this.height=height;
    }
    void setWeight(int weight){
        this.weight=weight;
    }
    void setHairColor(String hairColor){
        this.hairColor=hairColor;
    }
    void setName(String name){
        this.name=name;
    }
    void setPhone(String phone){
        this.phone=phone;
    }

    //getters

    int getHeight(){
        return this.height;
    }
    int getWeight(){
        return  this.weight;
    }
    String getHairColor(){
        return this.hairColor;
    }
    String getName(){
        return this.name;
    }
    String getPhone(){
        return this.phone;
    }


}
public class Test {
    public static void main(String[] args) {
        Human h=new Human();
        Human h2=new Human(45);
        Human h3=new Human(123,34,"yellow","sita","56789-56");
        // h.setHeight(23);
        // h.setWeight(67);
        // h.setName("riya");
        // System.out.println("height is: "+h.getHeight());
        // System.out.println("weight is : "+h.getWeight());
        // System.out.println("name is : "+h.getName());    
        
    }
}
