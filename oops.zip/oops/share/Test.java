package oops.share;

class Employee extends Human{

}

public class Test {
    public static void main(String[] args) {
        Employee e=new Employee();
        System.out.println(e.height);
      // System.out.println(e.weight);// private property
        System.out.println(e.phone); 
        System.out.println(e.name);   
    }

}
