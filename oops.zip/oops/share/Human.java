package oops.share;

public class Human {
    public int height=90;
    private int weight=89;
    String phone="232343-43343";
    protected String name="rani";
}
// class Human {
//     public int height=90;
//     private int weight=89;
//     String phone="232343-43343";
//     protected String name="rani";
// }