package oops.share2;
//whenever another package class has to be used =>import
import oops.share.Human;

class Student extends Human {

    void getInfo(){
         //   System.out.println(this.phone); //default 
         System.out.println(this.name); //protected=>private
    }

}

class Test2{
    public static void main(String[] args) {
        Student e=new Student();

        System.out.println(e.height);
      // System.out.println(e.weight);// private property
        // System.out.println(e.phone); //default 
        // System.out.println(e.name); //protected
    }
}